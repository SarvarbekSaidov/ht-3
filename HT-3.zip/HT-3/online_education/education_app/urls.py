from django.urls import path
from . import views

urlpatterns = [
    path('register/', views.register, name='register'),
    path('login/', views.login_view, name='login'),
    path('logout/', views.logout_view, name='logout'),
    path('add_student/', views.add_student, name='add_student'),
    path('register_for_course/<int:course_id>/', views.register_for_course, name='register_for_course'),
    path('students/', views.student_list, name='student_list'),
    path('', views.home, name='home'),
]
