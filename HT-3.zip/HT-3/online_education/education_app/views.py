from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth.forms import UserCreationForm, AuthenticationForm
from django.contrib.auth import login, logout, authenticate
from django.contrib.auth.decorators import login_required
from django.contrib import messages
from .forms import StudentForm
from .models import Course, Student

def register(request):
    if request.method == 'POST':
        user_form = UserCreationForm(request.POST)
        student_form = StudentForm(request.POST)
        if user_form.is_valid() and student_form.is_valid():
            user = user_form.save()
            student = student_form.save(commit=False)
            student.user = user
            student.save()
            messages.success(request, 'Account created successfully')
            return redirect('login')
    else:
        user_form = UserCreationForm()
        student_form = StudentForm()
    return render(request, 'register.html', {'user_form': user_form, 'student_form': student_form})

def login_view(request):
    if request.method == 'POST':
        form = AuthenticationForm(data=request.POST)
        if form.is_valid():
            user = form.get_user()
            login(request, user)
            messages.success(request, 'Logged in successfully')
            return redirect('home')
        else:
            messages.error(request, 'Invalid credentials')
    else:
        form = AuthenticationForm()
    return render(request, 'login.html', {'form': form})

def logout_view(request):
    logout(request)
    messages.success(request, 'Logged out successfully')
    return redirect('login')

@login_required
def register_for_course(request, course_id):
    course = get_object_or_404(Course, id=course_id)
    student, created = Student.objects.get_or_create(user=request.user)

    if course not in student.courses.all():
        student.courses.add(course)
        messages.success(request, f'You have successfully registered for {course.title}')
    else:
        messages.info(request, f'You are already registered for {course.title}')

    return redirect('home')

def add_student(request):
    if request.method == 'POST':
        form = StudentForm(request.POST, request.FILES)
        if form.is_valid():
            form.save()
            messages.success(request, 'Student added successfully')
            return redirect('home')
    else:
        form = StudentForm()
    return render(request, 'add_student.html', {'form': form})

def home(request):
    courses = Course.objects.all()
    return render(request, 'home.html', {'courses': courses})

@login_required
def student_list(request):
    students = Student.objects.all()
    return render(request, 'student_list.html', {'students': students})
