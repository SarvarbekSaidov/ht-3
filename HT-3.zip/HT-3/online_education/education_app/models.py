from django.contrib.auth.models import User
from django.db import models

class Course(models.Model):
    title = models.CharField(max_length=200)
    description = models.TextField()
    image = models.ImageField(upload_to='course_images/', blank=True, null=True)

    def __str__(self):
        return self.title

class Student(models.Model):
    user = models.OneToOneField(User, on_delete=models.CASCADE, default=1)   
    name = models.CharField(max_length=100)
    email = models.EmailField()
    image = models.ImageField(upload_to='student_images/', blank=True, null=True, default='images/student_default_image.jpg')
    courses = models.ManyToManyField(Course)

    def __str__(self):
        return self.name

